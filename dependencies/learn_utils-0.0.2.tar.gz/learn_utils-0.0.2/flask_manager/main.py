"""
Main module - Flask-Manager main module.
"""
from flask_manager import manager
from invoke import Collection, Program, task
from .utils import import_string, check_module_existence
import sys
import os

# set the current working directory in the sys.path
# we consider that the current working directory is the flask-project root path
# adding current working path to the sys.path enables flask-manager capabilities such as blueprints auto discover
# and automatic script finding
sys.path.insert(0, os.getcwd())

# check if the tasks.py file exists and then import it
if check_module_existence('tasks'):
    mod = import_string('tasks')
    namespace = mod.namespace
else:
    # initialize a collection object otherwise
    namespace = Collection()

# register the current file to the manager
namespace.add_task(manager.init_project, "init-project")
namespace.add_task(manager.init_blueprint, "init-blueprint")

namespace.add_task(manager.run, "run")
namespace.add_task(manager.test, "test")
namespace.add_task(manager.behave, "behave")

program = Program(namespace=namespace, version='0.0.1')