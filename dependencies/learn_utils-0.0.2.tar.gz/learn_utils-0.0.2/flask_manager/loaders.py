"""
loaders module defines classes and methods that builds flask applications and blueprints.
"""
from flask import Flask, Blueprint

from flask_manager import utils
import types


def instantiate_flask_application(app_dotted_path, settings_dotted_path=None):
    """
    Instantiates flask an application.
    :param app_dotted_path: the app path dotted path to the flask application.
    :param settings_dotted_path: a doted path to the flask-app settings.
    :return: an Flask application instance.
    """
    if app_dotted_path != '' and app_dotted_path is not None:
        app_module = utils.import_string(app_dotted_path)
        app_name = app_module.__name__
    else:
        app_name = __name__

    if not isinstance(settings_dotted_path, types.ModuleType):
        if settings_dotted_path is None or settings_dotted_path == "":
            if app_dotted_path != '' and app_dotted_path is not None:
                settings_dotted_path = app_dotted_path + ".settings"
            else:
                settings_dotted_path = 'settings'
        settings = utils.import_string(settings_dotted_path)
    else:
        settings = settings_dotted_path

    import os
    # get some configuration from the settings file.
    static_path = getattr(settings, 'static_path', None)
    static_url_path = getattr(settings, 'static_url_path', '')
    static_folder = getattr(settings,'static_folder', 'static')
    template_folder = getattr(settings, 'template_folder', 'templates')
    instance_path = getattr(settings, 'instance_path', os.getcwd())
    instance_relative_config = getattr(settings, 'instance_relative_config', False)
    root_path = getattr(settings, 'root_path', os.getcwd())
    app_name = getattr(settings,'APP_NAME', app_name)
    # instantiate Flask
    app = Flask(
        app_name,
        static_path=static_path,
        static_url_path=static_url_path,
        static_folder=static_folder,
        template_folder=template_folder,
        instance_path=instance_path,
        instance_relative_config=instance_relative_config,
        root_path=root_path
    )
    on_init = getattr(settings, 'on_app_initialization', None)
    if on_init is not None:
        on_init(app)
    """
    Load app config from the config file in the first time that our 
    """
    import os
    flask_config = os.getenv('FLASK_CONFIG')
    if not flask_config:
        flask_config = 'local'

    try:
        if hasattr(settings,'CONFIG_NAME_MAPPER'):
            app.config.from_object(settings.CONFIG_NAME_MAPPER[flask_config])
        else:
            app.config.from_object(settings)

    except ImportError:
        if flask_config == 'local':
            raise FileNotFoundError(
                "You have to have `local_config.py` in order to use the default 'local' Flask Config. "
                "Alternatively, you may set `FLASK_CONFIG` environment variable to one of the following options: "
                "development, production"
            )
    # loads the urls.py project file and register its urls rules
    with app.app_context():
        load_urls(app,app_dotted_path)
    return app


def register_blueprints(app):
    """
    Auto-discover INSTALLED BLUEPRINT APPS modules and register them to the app received as parameters.
    :param app: Already configured Flask app instance.
    :return: All registered BLUEPRINTS.
    """

    modules = utils.autodiscover(app)

    for mod in modules:
        static_folder = getattr(mod, "static_folder", 'static')
        static_url_path = getattr(mod, "static_url_path", '')
        template_folder = getattr(mod, "template_folder", 'templates')
        url_prefix = getattr(mod, "url_prefix", None)
        subdomain = getattr(mod, "subdomain", None)
        url_defaults = getattr(mod, "url_defaults", None)
        root_path = getattr(mod, "root_path", None)
        # App instantiation
        blueprint = Blueprint(
            mod.__name__.split('.')[-1],
            mod.__name__,
            static_folder=static_folder,
            static_url_path=static_url_path,
            template_folder=template_folder,
            url_prefix=url_prefix,
            subdomain=subdomain,
            url_defaults=url_defaults,
            root_path=root_path
        )
        if hasattr(mod,'on_app_initialization'):
            on_init = getattr(mod, 'on_app_initialization', None)
            on_init(app, blueprint)

        load_urls(blueprint, mod.__name__)
        app.register_blueprint(blueprint, url_prefix='/'+blueprint.name)


def load_settings_file(settings_dotted_path):
    """
    a short-cut  function that
    loads and returns the settings module file from the given dotted path.
    :param settings_dotted_path: a doted path to the flask-app settings.
    :return: the loaded application settings module.
    """
    if settings_dotted_path.split('.')[-1] != 'settings':
        if settings_dotted_path != '' and settings_dotted_path is not None:
            settings_dotted_path += '.settings'
        else:
            settings_dotted_path = 'settings'
    settings = utils.import_string(settings_dotted_path)
    return settings


def build_flask_app(app, settings):
    app = instantiate_flask_application(app, settings)
    with app.app_context():
        register_blueprints(app)
    return app


def load_urls(app, app_dotted_path=None):
    """
    loads the an url.py file and runs its register_urls function.
    :param app_dotted_path: dotted path to the app
    """
    if app_dotted_path is None or app_dotted_path == '':
        app_dotted_path = 'urls.register_urls'
    else:
        app_dotted_path += '.urls.register_urls'

    loader_func = utils.import_string(app_dotted_path)
    if not callable(loader_func):
        raise TypeError(
            "'register_urls' must be a callable object."
            "'register_urls' also must have the following signature:"
            "'register_urls(app)'"
        )

    loader_func(app)