"""
Utils Manager module. 
Defines utility functions that helps to manage the Flask application and BluePrints

"""
from importlib import import_module
import importlib
import sys
import os
import six


def import_string(dotted_path):
    """
    Import a dotted module path and return the attribute/class designated by the
    last name in the path. Raise ImportError if the import failed.
    """
    if '.' not in dotted_path:
        return import_module(dotted_path)
    else:

        try:
            module_path, class_name = dotted_path.rsplit('.', 1)
        except ValueError:
            msg = "%s doesn't look like a module path" % dotted_path
            six.reraise(ImportError, ImportError(msg), sys.exc_info()[2])

        module = import_module(module_path)

        try:
            return getattr(module, class_name)
        except AttributeError:
            msg = 'Module "%s" does not define a "%s" attribute/class' % (
                dotted_path, class_name)
            six.reraise(ImportError, ImportError(msg), sys.exc_info()[2])


def autodiscover(app, *args, **kwargs):
    """
    Auto-discover INSTALLED_APPS modules and fail silently when
    not present. This forces an import on them to register any admin bits they
    may want.
    """
    BLUEPRINTS = app.config['BLUE_PRINTS']
    mods = []
    for blueprint in BLUEPRINTS:
        # Attempt to import the app's module.
        try:
            mod = import_module(blueprint)
            mods.append(mod)
        except:
            pass

    return mods


def create_flask_app(log_name=None):
    """loads system settings and modules and then creates a flask app object. """
    from flask_manager.loaders import load_settings_file, build_flask_app
    settings = load_settings_file('settings')
    load_environment_variables(settings)

    # reload settings to grant configuration consistency
    from importlib import reload
    reload(settings)

    # initialize log if it has one
    if hasattr(settings, 'LOG_MODULE'):
        log_module = getattr(settings, 'LOG_MODULE', 'logger')
        logger = import_string(log_module)
        if log_name:
            logger.init(log_name)
        else:
            logger.init('run_dev')

    app = build_flask_app('', settings)
    return app


def check_module_existence(dotted_path):
    """
    Returns true if the module exists and false otherwise.
    :param dotted_path: module dotted_path string.
    """
    spam_spec = importlib.util.find_spec(dotted_path)
    found = spam_spec is not None
    return found


def load_environment_variables(settings):
    """
    Load environment variables defined in config.json
    """
    import json
    config_json = json.load(open(settings.GUNICORN_CONFIG['env_vars_path']))

    for key in config_json.keys():
        if key not in os.environ:
            os.environ[key] = config_json[key]