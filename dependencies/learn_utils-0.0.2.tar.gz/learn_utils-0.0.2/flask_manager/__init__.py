"""
flask-manager provides command-line utilities for flask applications.
it is intended to give support for common administrative and development, and deployment tasks.

This pack is intended to be flexible enough to give users a easy ways to extend the commands and their behaviours.

Task from this module are called from the command line in the following format:
flask-manager [command]
"""
from flask.globals import LocalProxy
import flask
# region app_config_proxy


def __current_app__():
    # a proxy to the current running app
    _app = flask.current_app
    return _app


def __current_config__():
    # a proxy to the current running app configuration
    _config = flask.current_app.config
    return _config

c_app = LocalProxy(__current_app__)
c_config = LocalProxy(__current_config__)

# endregion
