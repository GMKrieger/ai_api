"""
guinicorn application module -
    defines a simple and generic gunicorn application class used to run flask applications 
    from the flask_manager package.
                               
"""
import json
import os

from gunicorn.app.base import Application

from aws_utils import aws_logger
from flask_manager.loaders import build_flask_app


class GunicornApp(Application):
    """
    Gunicorn application class.
    """

    def __init__(self, settings):
        self.settings = settings
        super().__init__()

    def init(self, parser, opts, args):
        self.load_config_from_module_name_or_filename(self.settings.GUNICORN_CONFIG['config_path'])

    def load(self):
        api = build_flask_app('', self.settings)
        return api