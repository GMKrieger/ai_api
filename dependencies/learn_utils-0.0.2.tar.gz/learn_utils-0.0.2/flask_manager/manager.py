"""
Manager module - Is a ManagementUtility that encapsulates the logic of the common project management tasks.
    
    This module defines a set of common automated develop and deployment tasks.
"""
import os
import subprocess
import sys
from invoke import task
from .loaders import load_settings_file
from . import utils


@task(default=True)
def run(context, dev=False):
    """
    Start the Server with Gunicorn
    """
    from .loaders import build_flask_app
    settings = load_settings_file('settings')

    if dev:
        utils.load_environment_variables(settings)

        # reload settings to grant configuration consistency
        from importlib import reload, import_module
        reload(settings)
        # initialize log if it has one
        if hasattr(settings, 'LOG_MODULE'):
            log_module = getattr(settings, 'LOG_MODULE', 'logger')
            logger = import_module(log_module)
            logger.init('run_dev')

        app = build_flask_app('', settings)
        with app.app_context():
            app.run()
    else:
        # Hack to load environment variables when running Gunicorn locally
        if os.getenv('FLASK_CONFIG') is None:
            utils.load_environment_variables(settings)
            # reload settings to grant configuration consistency
            from importlib import reload
            reload(settings)

        from flask_manager.gunicorn.application import GunicornApp
        app = GunicornApp(settings)
        # with app.current_context():
        app.run()


# TODO: Create static/docs folder containing Sphix documentation
@task
def test(context, path=None, cov=None, ):
    """
    Execute tests
    """

    settings = load_settings_file('settings')

    params = ['-x', '-s', '-vv', '--cov-report=term-missing',
              '--cov-report=html:static/coverage', '--ignore=env']
    if cov:
        params.append('--cov={}'.format(cov))

    utils.load_environment_variables(settings)
    # reload settings to grant configuration consistency
    from importlib import reload
    reload(settings)

    if path is not None:
        params = [path] + params

    import pytest
    sys.exit(pytest.main(params))


# TODO: Create tests/features folder containing behave tests
@task
def behave(context, path=None):
    """
    Execute digibot tests
    """
    params = ['behave', 'tests/features']

    from .loaders import load_settings_file
    settings = load_settings_file('settings')

    if path is not None:
        params.append(path)

    utils.load_environment_variables(settings)

    # reload settings to grant configuration consistency
    from importlib import reload
    reload(settings)

    subprocess.run(params, check=True)


def build_test_dir(parent):
    # checks if the '/tests' folder already exists
    path = parent+'/tests' if parent != '' and parent is not None else 'tests'
    if not os.path.exists(path):
        # then creates the 'tests' directory and the init files
        os.mkdir(path)
        init_file = open(path+'/__init__.py', mode='w')
        init_file.close()
    else:
        if not os.path.exists(path+'/__init__.py'):
            init_file = open(path+'/__init__.py', mode='w')
            init_file.close()

@task
def init_project(context):
    """
    Initialize project file structure in the current directory.
    :param context: 
    :return: 
    """
    # checks if the static folder already exists, and then create a new one whether not
    if not os.path.exists('static'):
        print("static-creating")
        os.mkdir('static')

    build_test_dir('')

    # get project installation path at run time
    import flask_manager
    import inspect
    project_path = inspect.getmodule(flask_manager).__path__[0]

    # builds the settings.py file
    with open('settings.py','w') as f:
        settings_text = ''
        with open(project_path+'/project_template/settings.txt') as template_f:
            settings_text = template_f.read()

        # get at run time the path to the gunicorn module
        from flask_manager import gunicorn
        from string import Template
        wsgi_path = inspect.getmodule(gunicorn).__path__[0]
        template = Template(settings_text)
        # format the input template with the correct wsgi path, and writes to the file.
        f.write(template.substitute({'wsgi':wsgi_path}))


    # builds the tasks.py file
    with open('tasks.py', 'w') as f:
        tasks_text = ''
        with open(project_path+'/project_template/tasks.txt', 'r') as template_f:
            tasks_text = template_f.read()
        f.write(tasks_text)

    # builds thhe urls.py file
    with open('urls.py', 'w') as f:
        urls_text = ''
        with open(project_path + '/project_template/urls.txt', 'r') as template_f:
            urls_text = template_f.read()
        f.write(urls_text)

@task
def init_blueprint(context, name):
    # get project installation path at run time
    import flask_manager
    import inspect
    import os
    project_path = inspect.getmodule(flask_manager).__path__[0]

    # checks if the static folder already exists, and then create a new one whether not
    if not os.path.exists(name):
        os.mkdir(name)
    else:
        print("Blueprint path already exists.")
    # builds the static directory
    if not os.path.exists(name+'/static'):
        os.mkdir(name+'/static')

    build_test_dir(name)

    # builds thhe urls.py file
    with open(name+'/urls.py', 'w') as f:
        urls_text = ''
        with open(project_path + '/blueprint_template/urls.txt', 'r') as template_f:
            urls_text = template_f.read()
        f.write(urls_text)

    # builds the __init__.py file
    with open(name + '/__init__.py', 'w') as f:
        init_text = ''
        with open(project_path + '/blueprint_template/__init__.txt', 'r') as template_f:
            init_text = template_f.read()
        f.write(init_text)

    # updating settings.py file
    settings_text = ''
    with open('settings.py', 'r') as f:
        settings_text = f.read()
    settings_text = settings_text.replace('BLUE_PRINTS = [','BLUE_PRINTS = ["{}",'.format(name))

    with open('settings.py', 'w') as f:
        f.write(settings_text)


