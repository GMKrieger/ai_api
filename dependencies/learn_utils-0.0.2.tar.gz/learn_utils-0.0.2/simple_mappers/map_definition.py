"""
Map Definition Module: Defines the main class that is able to map attrubtes from one object to other.
"""
from .properties import BaseProperty
from .utils import get_object_attrs
import inspect


class MapDefinition(object):
    """
    Base Map definition class.
    """
    # Common methods for handling properties on mapping object.
    __properties__ = dict()
    cascade = True

    def __init__(self, map_undefined=False, **kwargs):
        """Manager Initialization function."""
        # builds the object from the kwargs mappings
        for property_name, property_instance in self._properties.items():
            # handling mapping names
            p_name = property_name
            if isinstance(property_instance, BaseProperty):
                if property_instance.mapping_name:
                    p_name = property_instance.mapping_name
            # when cascade is set to true
            # then the property wil be mapper from a single entry in the kwargs
            if property_instance.cascade:
                # if attrbute name is not in kwargs
                # then handles with default values and different attribute name mappings
                if p_name not in kwargs:
                    # then check if the current attribute has a defined default value.
                    attr_value = property_instance.inflate(None)
                    # if it has a defined default value
                    # then set this default value to the object being built
                    # None otherwise
                    setattr(self, property_name, attr_value)
                else:  # else attribute name is in kwargs
                    # then set the attribute name and value to the object being built
                    attr_value = property_instance.inflate(kwargs[p_name])
                    setattr(self, property_name, attr_value)
                    # remove property from kwargs
                    del kwargs[p_name]
            # otherwise the property will be mapped from the whole dictionary
            else:
                attr_value = property_instance.inflate(kwargs)
                setattr(self, property_name, attr_value)

        if map_undefined:
            # undefined properties last (for magic @prop.setters etc)
            for property_name, property_instance in kwargs.items():
                setattr(self, property_name, property_instance)

    @property
    def _properties(self):
        """Return the list of defined class properties."""
        if len(self.__properties__) == 0:
            self.__properties__ = self.__class__.get_defined_properties()

        return self.__properties__

    @classmethod
    def get_defined_properties(cls)->dict:
        """
        Builds and returns the object property dictionary.
        """
        if len(cls.__properties__) == 0:
            props = dict()
            # for each derived class of the current class
            # gets the class public properties attributes and builds a dictionary with them.
            for scls in cls.mro():  # runs in the type resolution order
                for prop_name, prop_instance in scls.__dict__.items():
                    if not prop_name.startswith("_"):
                        if issubclass(type(prop_instance), BaseProperty):
                            props[prop_name] = prop_instance  # aways overrides properties
                        elif inspect.isclass(prop_instance) and issubclass(prop_instance, MapDefinition):
                            props[prop_name] = prop_instance  # aways overrides properties

            cls.__properties__ = props

        return cls.__properties__

    @classmethod
    def from_json(cls, json, map_undefined=False):
        """
        Maps a json to a new instance of the object type.
        :param json:  a parsed json object.
        :param map_undefined: if true undefined attributes will be mapped to the object instance.
        :return: a instance of the object.
        """
        return cls(map_undefined=map_undefined, **json)

    @classmethod
    def from_object(cls, obj, map_undefined=False):
        """
        Maps the object received as parameter to a new object instance of the current class class. 
        :param obj: an object instance.
        :param map_undefined: if true unmapped attributes will be mapped to the new object instance.
        :return: a instance of the current object type.
        """
        obj_props = get_object_attrs(obj)
        kwargs = dict()
        for prop_name, val in obj_props.items():
            kwargs[prop_name] = val

        return cls(map_undefined=map_undefined, **kwargs)

    def to_object(self, obj):
        """
        Mapps the current object attributes to a target object.
        :param obj: an target objecct instance.
        """
        # for each mapped properties
        for prop_name, prop_def in self._properties.items():
            # get attr val
            attr_val = getattr(self, prop_name, None)
            is_class = inspect.isclass(attr_val)
            # check attr mapping name
            if not is_class and prop_def.mapping_name:
                prop_name = prop_def.mapping_name

            # sanity type check
            if isinstance(attr_val, BaseProperty) or is_class:
                attr_val = None
            # deflate property value
            attr_val = prop_def.deflate(attr_val)  # TODO when val is a MAPPING DEFINITION CALL TO_OBJECT???
            # set to the target object
            setattr(obj, prop_name, attr_val)

    def to_json(self, should_map=True):
        """
        Returns a json representation of the current object.
        :return: a json object representation of the current object.
        """
        obj = dict()
        # for each mapped properties
        for prop_name, prop_def in self._properties.items():
            # get attr val
            attr_val = getattr(self, prop_name, None)
            is_class = inspect.isclass(prop_def)
            # check attr mapping name
            if should_map and not is_class and prop_def.mapping_name:
                prop_name = prop_def.mapping_name

            # sanity type check
            # if not isinstance(attr_val, BaseProperty) and not is_class:
            if not isinstance(attr_val, BaseProperty) and not inspect.isclass(attr_val):
                # deflate property value
                if isinstance(attr_val, MapDefinition):
                    attr_val = attr_val.to_json()
                else:
                    attr_val = prop_def.deflate(attr_val)
                obj[prop_name] = attr_val

        return obj

    @classmethod
    def inflate(cls, value: dict):
        if value:
            return cls.from_json(value)
        return None

    @staticmethod
    def deflate(value):
        return value.to_object(value)
