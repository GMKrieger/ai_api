"""
properties module - defines class properties attributes.
"""
import collections
import datetime
import pytz
import json


class BaseProperty(object):
    """
    Base class for object properties
    """

    def __init__(self, required=False, default=None, mapping_name=None, cascade=True, **kwargs):
        """
        A Base class property definition. 
        :param required: True if the attribute is required.
                         When true and it is not possible to map the attribute from the other object,
                         it raises a value error exception. 
        :param default: default value or function generator.
        :param mapping_name: the name of the attribute in the other object
        :param cascade: when true mappers try to map the the property from the other object properties.
        :param kwargs:
        """
        if default is not None and required:
            raise ValueError("required and default arguments are mutually exclusive")

        self.required = required
        self.default = default
        self.has_default = True if self.default is not None else False
        self.mapping_name = mapping_name  # define the name of the property in the database
        self.cascade = cascade

    def default_value(self):
        """
        Generate a default value

        :return: the value
        """
        if self.has_default:
            if callable(self.default):
                return self.default()
            else:
                return self.default
        else:
            return None

    def inflate(self, value):
        """
        returns default or value. 
        """
        if value is None:
            return self.default_value()
        else:
            return value

    def deflate(self, value):
        """
        returns default or value. 
        """
        if value is None:
            return self.default_value()
        else:
            return value


class ChoiceProperty(BaseProperty):
    """
    Defines a base choosable base property.
    """

    def __init__(self, choices=None, **kwargs):
        """
        Choice property type initialization.
        :param choices: a list of possible string values.
                        or a dict mapping the possible incoming values to its transformed values.

        :param kwargs required: True if the attribute is required.
                         When true and it is not possible to map the attribute from the other object,
                         it raises a value error exception. 
        :param kwargs default: default value or function generator.
        :param kwargs source_name: the name of the attribute in the other object
        """
        super(ChoiceProperty, self).__init__(**kwargs)
        # if choices
        if choices is not None:
            # sanity type check in choices
            if not isinstance(choices, (tuple, list, dict)):
                raise TypeError("Choices must be a tuple, a list or a dict.")
            # if choices is a dict map
            # then saves the mapping dictionary
            if isinstance(choices, dict):
                self.choices = choices.keys()
                self.choice_map = choices
                # choices reverse map
                self.choice_reverse_map = dict(zip(
                    self.choice_map.values(),
                    self.choice_map.keys()
                ))
            else:  #
                self.choices = choices
                self.choice_map = None
                self.choice_reverse_map = None
        else:
            self.choices = None
            self.choice_map = None
            self.choice_reverse_map = None

    def inflate(self, value):
        """Returns the value that should be used to fill the object being mapped."""
        value = super().inflate(value)

        if self.choice_map:
            if value not in self.choice_map:
                raise ValueError(
                    "Invalid attribute value {}."
                    " Possible values are {}.".format(value, self.choices)
                )

            return self.choice_map[value]
        elif self.choices:
            if value not in self.choices:
                raise ValueError(
                    "Invalid attribute value {}."
                    " Possible values are {}.".format(value, self.choices)
                )
        return value

    def deflate(self, value):
        """Returns the value that should be used to send to the object being mapped."""
        value = super().deflate(value)

        if self.choice_map:
            if value not in self.choice_reverse_map:
                raise ValueError(
                    "Invalid attribute value {}."
                    " Possible values are {}.".format(value, self.choice_reverse_map.keys())
                )

            return self.choice_reverse_map[value]
        elif self.choices and value not in self.choices:
            raise ValueError(
                "Invalid attribute value {}."
                " Possible values are {}.".format(value, self.choices)
            )

        return value


class NormalProperty(BaseProperty):
    """
    Base class for normalized properties.
    """
    def __init__(self, norm_func=None, denorm_func=None, **kwargs):
        """
        Normal property type initialization.
        :param norm_func: a value normalization function.
        :param denorm_func: a value denormalization function.
        """
        super(NormalProperty, self).__init__(**kwargs)
        self.normalize = norm_func
        self.denormalize = denorm_func

    def inflate(self, value):
        """
        returns the normalized property value
        """
        value = super().inflate(value)

        if value is None:
            return None

        if self.normalize is not None:
            return self.normalize(value)
        else:
            return value

    def deflate(self, value):
        """
        returns the normalized property value
        """
        value = super().deflate(value)
        if value is None:
            return None
        if self.denormalize is not None:
            return self.denormalize(value)
        else:
            return value


class StringProperty(ChoiceProperty, NormalProperty):
    """
    Defines an string property mapper object.
    """

    def __init__(self, **kwargs):
        """
        String property type initialization.
        :param choices: a list of possible string values.
                        or a dict mapping the possible incoming values to its transformed values.
                        
        :param kwargs required: True if the attribute is required.
                         When true and it is not possible to map the attribute from the other object,
                         it raises a value error exception. 
        :param kwargs default: default value or function generator.
        :param kwargs mapping_name: the name of the attribute in the other object
        """
        super(StringProperty, self).__init__(**kwargs)

    def inflate(self, value):
        """Returns the value that should be used to fill the object being mapped."""
        value = super().inflate(value)
        if value is not None:
            value = str(value)

        return value

    def deflate(self, value):
        """Returns the value that should be used to send to the object being mapped."""
        value = super().deflate(value)

        return value


class IntegerProperty(BaseProperty):
    """
    Stores an Integer value
    """

    def inflate(self, value):
        """Returns the value that should be used to fill the object being mapped."""
        value = super().inflate(value)
        if value:
            return int(value)
        return 0

    def deflate(self, value):
        """Returns the value that should be used to send to the object being mapped."""
        value = super().deflate(value)
        if value:
            return int(value)
        return 0


class ArrayProperty(BaseProperty):
    """
    Stores a list of items
    """

    def __init__(self, itens_type=None, **kwargs):
        """
        Store a list of values, optionally of a specific type.

        :param itens_type: List item type e.g StringProperty for string
        :type: Property
        """
        from simple_mappers.map_definition import MapDefinition
        # list item type
        if itens_type is not None:

            if not isinstance(itens_type, (BaseProperty,)) and not issubclass(itens_type, (MapDefinition,)):
                raise TypeError('Expecting Simple Mapper Property')

        self.itens_type = itens_type

        super(ArrayProperty, self).__init__(**kwargs)

    def inflate(self, value):
        """Returns the value that should be used to fill the object being mapped."""
        if isinstance(value, list) and len(value) == 0:
            value = None

        value = super().inflate(value)
        if not value:
            return None

        if isinstance(value, collections.Iterable):
            if self.itens_type:
                return [self.itens_type.inflate(item) for item in value]

            return list(value)
        else:
            raise TypeError("Ivalid attribute type {}. The property value must be a iterable type.")

    def deflate(self, value):
        """Returns the value that should be used to send to the object being mapped."""
        value = super().deflate(value)
        if value is None or len(value) == 0:
            return None

        if isinstance(value, collections.Iterable):
            if self.itens_type:
                return [self.itens_type.deflate(item) for item in value]

            return list(value)
        else:
            raise TypeError("Ivalid attribute type {}. The property value must be a iterable type.")


class FloatProperty(BaseProperty):
    """
    Store a floating point value
    """

    def inflate(self, value):
        value = super().inflate(value)
        return float(value)

    def deflate(self, value):
        value = super().deflate(value)
        return float(value)


class BooleanProperty(BaseProperty):
    """
    Stores a boolean value
    """

    def __init__(self, trues_str_list=None, **kwargs):
        super().__init__(**kwargs)

        if trues_str_list:
            self.trues = trues_str_list
        else:
            self.trues = ['true', '1', 't', 'y', 'yes', 's', 'sim']

    def inflate(self, value):
        if isinstance(value, str):
            value = self.bool_parser(value)
        return bool(value)

    def deflate(self, value):
        if isinstance(value, str):
            value = self.bool_parser(value)
        return bool(value)

    def bool_parser(self, s):
        return s.lower() in self.trues


class DateProperty(BaseProperty):
    """
    Stores a date
    """

    def __init__(self, mask=None, **kwargs):
        """
        Date property type initialization.
        :param mask: string datetime mask used to parse string dates.
                    or a dict mapping the possible incoming values to its transformed values.

        :param kwargs required: True if the attribute is required.
                         When true and it is not possible to map the attribute from the other object,
                         it raises a value error exception. 
        :param kwargs default: default value or function generator.
        :param kwargs source_name: the name of the attribute in the other object
        """
        super().__init__(**kwargs)
        if mask:
            self.mask = mask
        else:
            self.mask = "%Y-%m-%d"

    def inflate(self, value):
        value = super().inflate(value)
        if isinstance(value, str):
            return datetime.datetime.strptime(value, self.mask).date()
        elif isinstance(value, datetime.date):
            return value
        else:
            raise TypeError(
                "Value type Error: {}."
                " The value type must be a string or a 'datetime.date' object".format(type(value))
            )

    def deflate(self, value):
        value = super().deflate(value)
        if not isinstance(value, datetime.date):
            msg = 'datetime.date object expected, got {0}'.format(repr(value))
            raise TypeError(msg)
        return value.isoformat()


class DateTimeProperty(BaseProperty):

    def __init__(self, mask=None, **kwargs):
        """
        Datetime property type initialization.
        :param mask: string datetime mask used to parse string dates.
                    or a dict mapping the possible incoming values to its transformed values.

        :param kwargs required: True if the attribute is required.
                         When true and it is not possible to map the attribute from the other object,
                         it raises a value error exception. 
        :param kwargs default: default value or function generator.
        :param kwargs source_name: the name of the attribute in the other object
        """
        if mask:
            self.mask = mask
        else:
            self.mask = "%d/%m/%Y %H:%M"

        super(DateTimeProperty, self).__init__(**kwargs)

    def inflate(self, value):
        value = super().inflate(value)
        if isinstance(value, str):
            return datetime.datetime.strptime(value, self.mask)
        elif isinstance(value, datetime.datetime):
            return value
        elif isinstance(value, (float, int)):
            return datetime.datetime.utcfromtimestamp(value).replace(tzinfo=pytz.utc)
        else:
            raise TypeError('Value Type Error, got {0} cant inflate to datetime.'.format(value))

    def deflate(self, value):
        value = super().deflate(value)
        if isinstance(value, datetime.datetime):
            raise TypeError('Value Type Error, got {0} cant deflate to datetime.'.format(value))
        return value


class JSONProperty(BaseProperty):
    """
    Store a data structure as a JSON string.

    The structure will be inflated when a node is retrieved.
    """
    def __init__(self, *args, **kwargs):
        super(JSONProperty, self).__init__(*args, **kwargs)

    def inflate(self, value):
        value = super().inflate(value)
        if isinstance(value, dict):
            return value
        elif isinstance(value, str):
            return json.loads(value)
        else:
            msg = 'str or dict object expected, got {0}'.format(repr(value))
            raise TypeError(msg)

    def deflate(self, value):
        value = super().deflate(value)
        if not isinstance(value, dict):
            msg = 'str or dict object expected, got {0}'.format(repr(value))
            raise TypeError(msg)

        return value
