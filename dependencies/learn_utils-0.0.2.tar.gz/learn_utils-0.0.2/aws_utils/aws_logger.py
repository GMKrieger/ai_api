import sys
import logging
import datetime
import watchtower
import boto3
import botocore
import time


class AWSLogger(logging.Logger):
    log_format = "%(asctime)s [%(filename)s] [%(funcName)s] [%(levelname)s] [%(lineno)d] %(message)s"
    formatter = logging.Formatter(log_format)

    def __init__(self, pid):
        logger_name = "{}_worker_{}".format(datetime.datetime.now().strftime("%Y%m%dT%H%M%S%f"), pid)
        super().__init__(name=logger_name)

        self.addHandler(AWSLogger.get_stream_handler_instance())

    def add_watchtower_handler(self, log_group):
        self.addHandler(AWSLogger.get_cloudwatch_handler_instance(log_group))

    @staticmethod
    def get_stream_handler_instance():
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(AWSLogger.formatter)
        return console_handler

    @staticmethod
    def get_cloudwatch_handler_instance(log_group):
        try:
            cloudwatch_handler = watchtower.CloudWatchLogHandler(log_group=log_group,
                                                                 boto3_session=boto3.Session(region_name='sa-east-1'))
            cloudwatch_handler.setFormatter(AWSLogger.formatter)
            return cloudwatch_handler
        except botocore.errorfactory.OperationAbortedException:
            time.sleep(3)
            return AWSLogger.get_cloudwatch_handler_instance(log_group)

# logger instance
logger = None


def init(pid):
    """
    Logger initialization function. 
    This function is called from the flask-manager commands to initialize the log instance. 
    :param pid: WSGI process_id
    """
    global logger
    logger = AWSLogger(pid)

    from importlib import import_module
    settings = import_module("settings")

    if settings.flask_config == 'production' or (not settings.stream_logs_disable and settings.flask_config == 'test'):
        log_group = getattr(settings,"LOG_GROUP", "")
        logger.add_watchtower_handler(log_group)