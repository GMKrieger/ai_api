from setuptools import setup, find_packages
import os

# builds the project dependency list
install_requires = None
try:
    with open('requirements.txt', 'r') as f:
        install_requires = f.readlines()
except:  # in case of exception builds the list manually
    install_requires = [
        'boto3',
        'botocore',
        'click',
        'coverage',
        'docutils',
        'Flask',
        'gunicorn',
        'invoke',
        'itsdangerous',
        'Jinja2',
        'jmespath',
        'MarkupSafe',
        'py',
        'pytest',
        's3transfer',
        'six',
        'watchtower',
        'Werkzeug'
    ]

# setup function call
setup(
    name="learn_utils",
    version="0.0.2",
    author="Luis Felipe Muller, Joao Paulo Forny",
    author_email="",
    description=("Utility project code."),
    keywords="Flask,logger, manager",
    url="",
    # Install project dependencies
    install_requires=install_requires,

    package_data={
        # If any package contains *.txt or *.rst files, include them:
        '': ['*.txt', '*.rst', '*.md', "*.json"],
    },
    include_package_data=True,
    packages=find_packages(exclude=["*tests"]),
    entry_points={
        'console_scripts':['flask-manager = flask_manager.main:program.run']
    },

)
