from collections import MutableMapping

# sentinel used to check default values
_sentinel = object()

class CaseDict(MutableMapping):
    """
    A case-insensitive dictionary.
    """

    __slots__ = ('_data',)

    def __init__(self, __dict=None, **kwargs):
        # internal dictionary
        # keys are upper cased
        # stores tuples of (the original key, value)
        self._data = dict()
        if __dict is not None:
            self.update(__dict)
        if kwargs:
            self.update(kwargs)

    # Minimum set of methods required for MutableMapping

    def __len__(self):
        return len(self._data)

    def __iter__(self):
        for key, value in self._data.values():
            yield key, value

    def __getitem__(self, key:str):
        print(key)
        return self._data[key.upper()][1]

    def __setitem__(self, key:str, value):
        self._data[key.upper()] = (key, value)

    def __delitem__(self, key:str):
        del self._data[key.upper()]

    # Methods overriden to mitigate the performance overhead.

    def __contains__(self, key:str):
        return key.upper() in self._data

    def clear(self):
        """
        Removes all items from dictionary
        """
        self._data.clear()

    def get(self, key:str, default=_sentinel):
        """
        Gets the value from the key.
        If the key doesn't exist, the default value is returned, otherwise None.
        :param key: The dictionary key to get. 
        :param default: The default value to be returned when the key is not found in the dictionary.
        :return: The value
        """
        tup = self._data.get(key.upper())

        if tup is not None:
            return tup[1]
        elif default is not _sentinel:
            return default
        else:
            return None

    def pop(self, key:str, default=_sentinel):
        """
        Removes the specified key and returns the corresponding value.
        If key is not found, the default is returned if given, otherwise KeyError is raised.
        :param key: The key
        :param default: The default value
        :return: The value
        """
        if default is not _sentinel:
            tup = self._data.pop(key.upper(), default)
        else:
            tup = self._data.pop(key.upper())
        if tup is not default:
            return tup[1]
        else:
            return default

    # Other methods

    def __repr__(self):
        if self._data:
            return '%s(%r)' % (self.__class__.__name__, self._data)
        else:
            return '%s()' % self.__class__.__name__

    def items(self):
        return [(vals[0], vals[1]) for vals in self._data.values()]

    def keys(self):
        return self._data.keys()

    def values(self):
        return [vals[1] for vals in self._data.values()]