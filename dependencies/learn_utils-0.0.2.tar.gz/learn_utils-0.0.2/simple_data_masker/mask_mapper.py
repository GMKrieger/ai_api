from faker import Faker
from neo4py.models import PF, PJ, Endereco, Cidade, Pais
import pandas as pd

class MaskMapper(object):
    """A simple data mapper that masks the original data received."""

    def __init__(self):
        self.map = dict()
        self.fake = Faker('pt_BR')

    def map_attr(self):
        self.map['name'] = dict()
        self.map['cpf'] = dict()
        self.map['country_code'] = dict()
        self.map['city'] = dict()
        self.map['state'] = dict()
        self.map['job'] = dict()
        for entity in PF.nodes:

            entity.nm_cge = self._map('name',entity.nm_cge).upper()
            entity.cd_tax_identification = self._map('cpf',entity.cd_tax_identification).upper()
            entity.cd_pais_origem = self._map('country_code',entity.cd_pais_origem).upper()
            entity.cd_pais_domicilio_fiscal = self._map('country_code',entity.cd_pais_domicilio_fiscal).upper()
            entity.cd_cidade_nascimento = self._map('city',entity.cd_cidade_nascimento).upper()
            entity.cd_estado_nascimento = self._map('state',entity.cd_estado_nascimento).upper()

            entity.nm_profissao = self._map('job', entity.nm_profissao).upper()
            entity.save_or_update()
            print("pf mapped:", entity.cd_cge)

        self.map['company'] = dict()
        self.map['cnpj'] = dict()
        for entity in PJ.nodes:

            entity.nm_cge = self._map('company',entity.nm_cge).upper()
            entity.cd_tax_identification = self._map('cnpj',entity.cd_tax_identification).upper()
            entity.cd_pais_origem = self._map('country_code',entity.cd_pais_origem).upper()
            entity.cd_pais_domicilio_fiscal = self._map('country_code',entity.cd_pais_domicilio_fiscal).upper()
            entity.cd_cidade_nascimento = self._map('city',entity.cd_cidade_nascimento).upper()
            entity.cd_estado_nascimento = self._map('state',entity.cd_estado_nascimento).upper()
            entity.save_or_update()
            print("pj mapped:", entity.cd_cge)

        self.map['address'] = dict()
        self.map['building_number'] = dict()
        self.map['bairro'] = dict()
        self.map['postcode'] = dict()

        for end in Endereco.nodes:
            end.ds_endereco = self._map('address', end.ds_endereco).upper()
            end.nr_local = self._map('building_number', end.nr_local).upper()
            end.nm_bairro = self._map('bairro', end.nm_bairro).upper()
            end.cd_cep = self._map('postcode', end.cd_cep)
            end.save_io_update()
            print("Endereco mapped:", end.cd_cep)

        self.map['estado_nome'] = dict()
        self.map['country'] = dict()

        for cidade in Cidade.node:
            cidade.nm_cidade = self._map('city', cidade.nm_cidade).upper()
            cidade.sg_estado = self._map('estado_nome', cidade.sg_estado).upper()
            cidade.save_or_update()
            print("Cidade mapped:", cidade.nm_cidade)

        for pais in Pais.nodes:
            pais.nm_pais = self._map('country',pais.nm_pais).upper()
            pais.save_or_update()
            print("Pais mapped:", pais.nm_pais)

    def _map(self, key, value):
        if value not in self.map[key]:
            func = getattr(self.fake, key, None)
            name = func()
            self.map[key][value] = name
            return name

        else:
            return self.map[key][value]


if __name__ == "__main__":
    fake = Faker('pt_BR')
    path = "/home/luis/MyComputer/Projetos/AML-BTGREP/ingestion/data/v3/MASKED_OUTBOUND.TB_OUTBOUND_PARTY.csv"
    dtypes = {'NR_LOCAL': str, 'NM_CGE':str, 'CD_TAX_IDENTIFICATION':str}
    _map = dict()
    _map['name'] = dict()
    _map['cpf'] = dict()
    _map['country_code'] = dict()
    _map['city'] = dict()
    _map['state'] = dict()
    _map['job'] = dict()
    _map['company'] = dict()
    _map['cnpj'] = dict()
    i = 0
    def _m(key, value):
        if value not in _map[key]:
            if key == 'CD_TAX_IDENTIFICATION':
                global i
                key = 'cpf' if i % 2 == 0 else 'cnpj'
                i += 1

            func = getattr(fake, key, None)
            name = func()
            _map[key][value] = name
            return name

        else:
            return _map[key][value]

    df = f = pd.read_csv(path, index_col=None, encoding='latin-1', dtype=dtypes)
    mask = df['TP_PESSOA'] == 'F'
    df_1 = df.copy()
    df_2 = df.copy()
    df_1['NM_CGE'] = df[mask]['NM_CGE'].apply(lambda x: _m('name', x))
    df['NM_PAI'] = df[mask]['NM_PAI'].apply(lambda x: _m('name', x))
    df['NM_MAE'] = df[mask]['NM_MAE'].apply(lambda x: _m('name', x))
    df['NM_CONJUGE'] = df[mask]['NM_CONJUGE'].apply(lambda x: _m('name', x))
    df['NM_TRABALHO'] = df[mask]['NM_TRABALHO'].apply(lambda x: _m('company', x))
    df_1['CD_TAX_IDENTIFICATION'] = df[mask]['CD_TAX_IDENTIFICATION'].apply(lambda x: _m('cpf', x))
    df['NM_PROFISSAO'] = df[mask]['NM_PROFISSAO'].apply(lambda x: _m('job', x))

    mask = df['TP_PESSOA'] == 'J'
    df_2['NM_CGE'] = df[mask]['NM_CGE'].apply(lambda x: _m('company', x))
    df_2['CD_TAX_IDENTIFICATION'] = df[mask]['CD_TAX_IDENTIFICATION'].apply(lambda x: _m('cnpj', x))

    df['NM_CGE'] = pd.concat([df_1['NM_CGE'].dropna(), df_2['NM_CGE'].dropna()])
    df['CD_TAX_IDENTIFICATION'] =pd.concat([df_1['CD_TAX_IDENTIFICATION'].dropna(), df_2['CD_TAX_IDENTIFICATION'].dropna()])

    df.to_csv(
        path_or_buf='/home/luis/MyComputer/Projetos/AML-BTGREP/ingestion/data/v4/MASKED_OUTBOUND.TB_OUTBOUND_PARTY.csv',
        sep=',', index=False
    )

    path = "/home/luis/MyComputer/Projetos/AML-BTGREP/ingestion/data/v3/MASKED_OUTBOUND.TB_OUTBOUND_ADDRESS.csv"
    df = f = pd.read_csv(path, index_col=None, encoding='latin-1', dtype=dtypes)
    _map['address'] = dict()
    _map['building_number'] = dict()
    _map['bairro'] = dict()
    _map['postcode'] = dict()

    df['DS_ENDERECO'] = df['DS_ENDERECO'].apply(lambda x: _m('address', x))
    df['NR_LOCAL'] = df['NR_LOCAL'].apply(lambda x: _m('building_number', x))
    df['NM_BAIRRO'] = df['NM_BAIRRO'].apply(lambda x: _m('bairro', x))
    df['CD_CEP'] = df['CD_CEP'].apply(lambda x: _m('postcode', x))

    df.to_csv(
        path_or_buf='/home/luis/MyComputer/Projetos/AML-BTGREP/ingestion/data/v4/MASKED_OUTBOUND.TB_OUTBOUND_ADDRESS.csv',
        sep=',', index=False
    )

    path = "/home/luis/MyComputer/Projetos/AML-BTGREP/ingestion/data/v3/MASKED_OUTBOUND.TB_OUTBOUND_ACCOUNT_HOLDER.csv"
    df = f = pd.read_csv(path, index_col=None, encoding='latin-1', dtype=dtypes)
    _map["CD_TAX_IDENTIFICATION"] = dict(_map['cnpj'])
    _map["CD_TAX_IDENTIFICATION"].update(_map['cpf'])
    df['CD_TAX_IDENTIFICATION'] = df['CD_TAX_IDENTIFICATION'].apply(lambda x: _m('CD_TAX_IDENTIFICATION', x))

    df.to_csv(
        path_or_buf='/home/luis/MyComputer/Projetos/AML-BTGREP/ingestion/data/v4/MASKED_OUTBOUND.TB_OUTBOUND_ACCOUNT_HOLDER.csv',
        sep=',', index=False
    )

    path = "/home/luis/MyComputer/Projetos/AML-BTGREP/ingestion/data/v3/MASKED_OUTBOUND.TB_OUTBOUND_ASSOCIATION.csv"
    df = f = pd.read_csv(path, index_col=None, encoding='latin-1', dtype=dtypes)
    df['NR_CPF_CNPJ_ENTIDADE'] = df['NR_CPF_CNPJ_ENTIDADE'].apply(lambda x: _m('CD_TAX_IDENTIFICATION', x))
    df['NR_CPF_CNPJ_ENTIDADE_RELACIONADA'] = df['NR_CPF_CNPJ_ENTIDADE_RELACIONADA'].apply(lambda x: _m('CD_TAX_IDENTIFICATION', x))

    df.to_csv(
        path_or_buf='/home/luis/MyComputer/Projetos/AML-BTGREP/ingestion/data/v4/MASKED_OUTBOUND.TB_OUTBOUND_ASSOCIATION.csv',
        sep=',', index=False
    )